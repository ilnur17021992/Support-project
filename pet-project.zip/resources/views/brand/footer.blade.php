<p class="small m-n">
    © Copyright {{date('Y')}} 
    <span>Project</span>
</p>