@push('head')
<link href="/favicon.ico" id="favicon" rel="icon">
@endpush

<div class="h2 fw-light d-flex align-items-center">
    <x-orchid-icon path="help"/>
    <p class="ms-3 my-0 d-none d-sm-block">
        Support
        <small class="align-top opacity">Project</small>
    </p>
</div>