<p class="small m-n">
    © Copyright <?php echo e(date('Y')); ?> 
    <span>Project</span>
</p><?php /**PATH D:\OpenServer\domains\pet-project\resources\views/brand/footer.blade.php ENDPATH**/ ?>