<button formaction="<?php echo e(url()->current()); ?>/<?php echo e($notification->id); ?>/maskNotification"
        type="submit"
        class="btn btn-link text-start p-4">

    <span class="align-self-start text-<?php echo e($notification->data['type']); ?> <?php if($notification->read()): ?> opacity <?php endif; ?> pull-left m-t-sm small">
        <?php if (isset($component)) { $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc = $component; } ?>
<?php $component = Orchid\Icons\IconComponent::resolve(['path' => 'circle','class' => 'me-2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Orchid\Icons\IconComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc)): ?>
<?php $component = $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc; ?>
<?php unset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc); ?>
<?php endif; ?>
    </span>

    <span class="clear ps-3 d-block">
        <span class="w-100 w-b-k w-s-n"><?php echo e($notification->data['title'] ?? ''); ?></span>
        <small class="text-muted ps-1">/ <?php echo e($notification->created_at->diffForHumans()); ?></small>
        <br>
        <small class="text-muted w-100 w-b-k w-s-n"><?php echo $notification->data['message'] ?? ''; ?></small>
    </span>
</button>
<?php /**PATH D:\OpenServer\domains\pet-project\vendor\orchid\platform\resources\views/partials/notification.blade.php ENDPATH**/ ?>